/**
 * Quantum Calculator Logic
 * Handles arithmetic, history, and animations.
 */

class Calculator {
    constructor(historyEl, resultEl) {
        this.historyEl = historyEl;
        this.resultEl = resultEl;
        this.clear();
        this.readyToReset = false;
    }

    clear() {
        this.currentOperand = '0';
        this.previousOperand = '';
        this.operation = undefined;
        this.updateDisplay();
    }

    delete() {
        if (this.readyToReset) {
            this.clear();
            return;
        }
        if (this.currentOperand === '0') return;
        this.currentOperand = this.currentOperand.toString().slice(0, -1);
        if (this.currentOperand === '') this.currentOperand = '0';
        this.updateDisplay();
    }

    appendNumber(number) {
        if (this.readyToReset) {
            this.currentOperand = number;
            this.readyToReset = false;
            this.updateDisplay();
            return;
        }
        if (number === '.' && this.currentOperand.includes('.')) return;
        if (this.currentOperand === '0' && number !== '.') {
            this.currentOperand = number;
        } else {
            this.currentOperand = this.currentOperand.toString() + number.toString();
        }
        this.updateDisplay();
    }

    chooseOperation(operation) {
        if (this.currentOperand === '') return;
        if (this.previousOperand !== '') {
            this.compute();
        }
        this.operation = operation;
        this.previousOperand = this.currentOperand;
        this.currentOperand = '';
    }

    compute() {
        let computation;
        const prev = parseFloat(this.previousOperand);
        const current = parseFloat(this.currentOperand);
        if (isNaN(prev) || isNaN(current)) return;
        
        switch (this.operation) {
            case '+': computation = prev + current; break;
            case '-': computation = prev - current; break;
            case '*': computation = prev * current; break;
            case '/': computation = prev / current; break;
            default: return;
        }
        
        this.currentOperand = computation;
        this.operation = undefined;
        this.previousOperand = '';
        this.readyToReset = true;
        this.updateDisplay();
    }

    getDisplayNumber(number) {
        const stringNumber = number.toString();
        const integerDigits = parseFloat(stringNumber.split('.')[0]);
        const decimalDigits = stringNumber.split('.')[1];
        let integerDisplay;
        if (isNaN(integerDigits)) {
            integerDisplay = '';
        } else {
            integerDisplay = integerDigits.toLocaleString('en', { maximumFractionDigits: 0 });
        }
        if (decimalDigits != null) {
            return `${integerDisplay}.${decimalDigits}`;
        } else {
            return integerDisplay;
        }
    }

    updateDisplay() {
        this.resultEl.innerText = this.getDisplayNumber(this.currentOperand);
        if (this.operation != null) {
            this.historyEl.innerText = `${this.getDisplayNumber(this.previousOperand)} ${this.operation}`;
        } else {
            this.historyEl.innerText = '';
        }
        
        // Dynamic Font Scaling
        if (this.currentOperand.toString().length > 9) {
            this.resultEl.style.fontSize = '36px';
        } else if (this.currentOperand.toString().length > 6) {
            this.resultEl.style.fontSize = '46px';
        } else {
            this.resultEl.style.fontSize = '56px';
        }
    }

    negate() {
        if (this.currentOperand === '0') return;
        this.currentOperand = (parseFloat(this.currentOperand) * -1).toString();
        this.updateDisplay();
    }

    percent() {
        this.currentOperand = (parseFloat(this.currentOperand) / 100).toString();
        this.updateDisplay();
    }
}

// Init
document.addEventListener('DOMContentLoaded', () => {
    const historyEl = document.getElementById('history');
    const resultEl = document.getElementById('result');
    const calculator = new Calculator(historyEl, resultEl);

    // Button Clicks
    document.querySelectorAll('.btn').forEach(button => {
        button.addEventListener('click', () => {
            // Ripple Effect
            button.classList.add('ripple');
            setTimeout(() => button.classList.remove('ripple'), 300);
            
            // Logic
            if (button.classList.contains('num')) {
                if (button.dataset.num) calculator.appendNumber(button.dataset.num);
                if (button.dataset.action === '.') calculator.appendNumber('.');
            }
            if (button.classList.contains('op')) {
                calculator.chooseOperation(button.dataset.action);
            }
            if (button.dataset.action === 'AC') calculator.clear();
            if (button.dataset.action === '=') calculator.compute();
            if (button.dataset.action === '+/-') calculator.negate();
            if (button.dataset.action === '%') calculator.percent();
        });
    });

    // Keyboard support
    document.addEventListener('keydown', (e) => {
        if ((e.key >= 0 && e.key <= 9) || e.key === '.') calculator.appendNumber(e.key);
        if (e.key === '=' || e.key === 'Enter') calculator.compute();
        if (e.key === 'Backspace') calculator.delete();
        if (e.key === 'Escape') calculator.clear();
        if (e.key === '+' || e.key === '-' || e.key === '*' || e.key === '/') calculator.chooseOperation(e.key);
    });
});